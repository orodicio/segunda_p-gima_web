Sublime | Sans Serif

A smooth minimalist font | est 2019 by GOICHA. This demo font is for PERSONAL USE ONLY! 

But any donation is very appreciated.
►►► Paypal account for donation : paypal.me/goicha

Give your font library a complete upgrade 
►►► http://goicha.org/downloads/goichas-font-bundle/

Thank You


